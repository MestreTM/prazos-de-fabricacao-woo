function manufacturing_time_options_page() {
    ?>
    <div class="wrap">
        <h1>Configurações do Prazo de Fabricação</h1>
        <form action="options.php" method="post">
            <?php
                settings_fields('manufacturing_time_settings'); 
                do_settings_sections('manufacturing_time_settings'); 
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Prazo de Fabricação Padrão</th>
                    <td>
                        <input type="text" name="global_manufacturing_time" value="<?php echo esc_attr(get_option('global_manufacturing_time')); ?>" placeholder="Ex: 15 dias" />
                        <p class="description">Este prazo será exibido em todos os produtos que não tiverem um prazo específico definido.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?> 
        </form>
    </div>
    <?php
}

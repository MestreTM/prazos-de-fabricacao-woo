<?php
/*
Plugin Name: Prazo de Fabricação para Woo
Plugin URI: https://github.com/mestreTM/prazos-de-fabricacao-woo
Description: Este plugin adiciona a funcionalidade de prazo de fabricação no WooCommerce.
Version: 1.0
Author: William F.
Author URI: https://github.com/mestreTM/
License: GPL2
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
Text Domain: prazo-fabricacao-woo
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function prazo_fabricacao_sanitize( $input ) {
    return sanitize_text_field( $input );
}

function add_manufacturing_time_field() {
    woocommerce_wp_text_input( array(
        'id'          => '_manufacturing_time',
        'label'       => 'Prazo de Fabricação',
        'placeholder' => 'Ex: 10 dias',
        'description' => 'Insira o prazo de fabricação para este produto. Se não preencher, o prazo global será usado.',
        'desc_tip'    => true,
    ) );
}
add_action('woocommerce_product_options_general_product_data', 'add_manufacturing_time_field');

function save_manufacturing_time_field( $post_id ) {
    $manufacturing_time = isset( $_POST['_manufacturing_time'] ) ? sanitize_text_field( $_POST['_manufacturing_time'] ) : '';
    update_post_meta( $post_id, '_manufacturing_time', $manufacturing_time );
}
add_action( 'woocommerce_process_product_meta', 'save_manufacturing_time_field' );

function manufacturing_time_add_admin_menu() {
    add_options_page(
        'Configurações do Prazo de Fabricação',
        'Prazo de Fabricação',
        'manage_options',
        'manufacturing_time',
        'manufacturing_time_options_page'
    );
}
add_action('admin_menu', 'manufacturing_time_add_admin_menu');

function manufacturing_time_settings_init() {
    register_setting('manufacturing_time_settings', 'global_manufacturing_time', 'prazo_fabricacao_sanitize');
}
add_action('admin_init', 'manufacturing_time_settings_init');

function manufacturing_time_options_page() {
    ?>
    <div class="wrap">
        <h1>Configurações do Prazo de Fabricação</h1>
        <form action="options.php" method="post">
            <?php
                settings_fields('manufacturing_time_settings');
                do_settings_sections('manufacturing_time_settings');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Prazo de Fabricação Padrão</th>
                    <td>
                        <input type="text" name="global_manufacturing_time" value="<?php echo esc_attr(get_option('global_manufacturing_time')); ?>" placeholder="Ex: 15 dias" />
                        <p class="description">Este prazo será exibido em todos os produtos que não tiverem um prazo específico definido.</p>
                    </td>
                    <td>
                    <p class="description">Para definir um prazo especifico para um determinado produto, insira em dados do produto ao criar/editar o produto.</p>
                    <p class="description">Dados do produto > Geral > Prazo de Fabricação.</p>
                    <p class="description">Caso esteja definido um prazo em um produto especifico, será ignorado o prazo global definido aqui.</p>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function display_manufacturing_time_below_title() {
    global $product;
    if ( ! $product ) {
        return;
    }
    $manufacturing_time = get_post_meta( $product->get_id(), '_manufacturing_time', true );
    if ( empty($manufacturing_time) ) {
        $manufacturing_time = get_option('global_manufacturing_time');
    }
    if ( ! empty( $manufacturing_time ) ) {
        echo '<p class="manufacturing_time"><strong>Prazo de Fabricação:</strong> ' . esc_html( $manufacturing_time ) . '</p>';
    }
}
add_action( 'woocommerce_single_product_summary', 'display_manufacturing_time_below_title', 6 );

function display_manufacturing_time_in_cart( $cart_item_data, $product_id ) {
    $manufacturing_time = get_post_meta( $product_id, '_manufacturing_time', true );
    if ( empty( $manufacturing_time ) ) {
        $manufacturing_time = get_option('global_manufacturing_time');
    }
    if ( ! empty( $manufacturing_time ) ) {
        $cart_item_data['manufacturing_time'] = $manufacturing_time;
    }
    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'display_manufacturing_time_in_cart', 10, 2 );

function display_manufacturing_time_in_cart_item( $item_data, $cart_item ) {
    if ( isset( $cart_item['manufacturing_time'] ) ) {
        $item_data[] = array(
            'name'  => 'Prazo de Fabricação',
            'value' => $cart_item['manufacturing_time'],
        );
    }
    return $item_data;
}
add_filter( 'woocommerce_get_item_data', 'display_manufacturing_time_in_cart_item', 10, 2 );

remove_action( 'woocommerce_product_meta_start', 'woocommerce_template_single_meta', 40 );

function add_plugin_settings_link( $links ) {
    $settings_link = '<a href="options-general.php?page=manufacturing_time">Configurações</a>';
    array_push( $links, $settings_link );
    return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_plugin_settings_link' );

function display_manufacturing_time_in_order_admin( $order ) {
    echo '<h3>.</h3>';
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        $manufacturing_time = get_post_meta( $product->get_id(), '_manufacturing_time', true );
        if ( empty( $manufacturing_time ) ) {
            $manufacturing_time = get_option('global_manufacturing_time');
        }
        if ( ! empty( $manufacturing_time ) ) {
           echo '<h3>Prazo de Fabricação para os produtos:</h3>'; echo '<p><strong>' . esc_html( $manufacturing_time ) . '</strong> ';
        }
    }
}
add_action( 'woocommerce_admin_order_data_after_order_details', 'display_manufacturing_time_in_order_admin' );

function display_manufacturing_time_in_order_customer( $order ) {
    echo '<h3>Prazo de Fabricação para os produtos:</h3>';
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        $manufacturing_time = get_post_meta( $product->get_id(), '_manufacturing_time', true );
        if ( empty( $manufacturing_time ) ) {
            $manufacturing_time = get_option('global_manufacturing_time');
        }
        if ( ! empty( $manufacturing_time ) ) {
            echo '<p><strong>' . $item->get_name() . ':</strong> ' . esc_html( $manufacturing_time ) . '</p>';
        }
    }
}
add_action( 'woocommerce_order_details_after_customer_details', 'display_manufacturing_time_in_order_customer' );

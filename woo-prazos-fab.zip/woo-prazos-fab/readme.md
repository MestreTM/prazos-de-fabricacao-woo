=== Prazo de Fabricação para Woo ===
Contributors: William F.
Tags: woo, prazos de fabricação
Requires at least: 6.0
Requires PHP: 7.4
Tested up to: 6.7
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Permite definir um prazo de fabricação individual para cada produto e um prazo global padrão, exibindo essa informação abaixo do título do produto e no carrinho.
